import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:texttospeecch/home/my_game_home_page.dart';

void main() async {
  await GetStorage.init();
  await GetStorage().write('lampStatus', false);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyGameHomePage(),
    );
  }
}
