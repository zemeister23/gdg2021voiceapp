import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_speech/flutter_speech.dart';
import 'package:get_storage/get_storage.dart';
import 'package:porcupine_flutter/porcupine.dart';
import 'package:porcupine_flutter/porcupine_error.dart';
import 'package:porcupine_flutter/porcupine_manager.dart';
import 'package:texttospeecch/speech/language_model.dart';

class MyGameHomePage extends StatefulWidget {
  @override
  State<MyGameHomePage> createState() => _MyGameHomePageState();
}

class _MyGameHomePageState extends State<MyGameHomePage> {
  // ? INITSTATE
  @override
  void initState() {
    super.initState();
    initJarvis();
    activateSpeechRecognizer();
  }

  // ? SPEECH RECOGNIZING
  late SpeechRecognition _speech;
  String transcription = 'Speak';

  Language selectedLang = const Language('English', 'en_US');

  void activateSpeechRecognizer() {
    _speech = SpeechRecognition();
    _speech.setAvailabilityHandler(onSpeechAvailability);
    _speech.setRecognitionStartedHandler(onRecognitionStarted);
    _speech.setRecognitionResultHandler(onRecognitionResult);
    _speech.setRecognitionCompleteHandler(onRecognitionComplete);
    _speech.setErrorHandler(errorHandler);
    _speech.activate('en_EN').then((res) {});
  }

  void start() => _speech.activate(selectedLang.code).then((_) {
        return _speech.listen().then((result) {});
      });

  void cancel() => _speech.cancel().then((_) {
        initJarvis();
      });

  void stop() => _speech.stop().then((_) {});

  void onSpeechAvailability(bool result) {}

  void onRecognitionResult(String text) async {
    transcription = text;
    check(transcription);
    setState(() {});
  }

  void onRecognitionStarted() {}

  void onRecognitionComplete(String text) {
    if (text.toLowerCase().contains('navigate to game')) {
      page = 'game';
    } else if (text.toLowerCase().contains('navigate to smart')) {
      page = 'smart';
    } else {
      page = 'menu';
      GetStorage().write('score', score);
    }
    setState(() {});
    cancel();
  }

  void errorHandler() => activateSpeechRecognizer();

  // ? PORCUPINE Manager
  PorcupineManager? porcupineManager;
  final accessKey =
      "xcVy8tsSrdwOXLt59AyXfxjwv2CEU3CF2sn2aHe+Huuc7h9Y9kRa3w=="; // AccessKey obtained from Picovoice Console (https://picovoice.ai/console/)

  Future<void> createPorcupineManager() async {
    try {
      porcupineManager = await PorcupineManager.fromBuiltInKeywords(accessKey,
          [BuiltInKeyword.PICOVOICE, BuiltInKeyword.JARVIS], _wakeWordCallback);
      debugPrint("MANAGER CREATED !");
    } on PorcupineException catch (err) {
      debugPrint("MANAGER ERROR !: ${err.message}");
    }
  }

  void _wakeWordCallback(int keywordIndex) {
    if (keywordIndex == 1) {
      debugPrint("PORCUPINE DETECTED !");
      porcupineManager!.delete().then((value) => start());
    }
  }

  void listenForWake() async {
    await porcupineManager!.start();
    setState(() {});
  }

  void initJarvis() {
    try {
      createPorcupineManager().then((value) => listenForWake());
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  // ? UI
  int randNum = Random().nextInt(10) + 18;
  String page = 'menu';
  int score = 0;
  @override
  Widget build(BuildContext context) {
    switch (page) {
      // * Menu Home Page Widget
      case 'menu':
        return Scaffold(
          appBar: AppBar(
            title:
                const Text("Home Page", style: TextStyle(color: Colors.black)),
            elevation: 0,
            backgroundColor: Colors.transparent,
          ),
          body: Column(
            children: [
              Expanded(
                flex: 5,
                child: Container(
                  color: Colors.yellowAccent,
                  child: Center(
                    child: Text(
                      "Game\nLast Score: " +
                          (GetStorage().read('score').toString()),
                      style: TextStyle(fontSize: 33.0),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 5,
                child: Container(
                  color: Colors.indigoAccent,
                  child: Center(
                    child: Text(
                      "Smart Home\n${GetStorage().read('lampStatus') ? 'The Lamp Is On' : 'The Lamp Is Off'}",
                      style: TextStyle(fontSize: 33.0),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      // * Smart Home Page Widget
      case 'smart':
        return Scaffold(
          body: Column(
            children: [
              Expanded(
                child: Image.asset(
                  GetStorage().read('lampStatus')
                      ? 'assets/lamp_on.png'
                      : 'assets/lamp_off.png',
                ),
              ),
            ],
          ),
        );
      // * Game Page Widget
      default:
        return Scaffold(
          body: Center(
            child: SizedBox(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3),
                itemBuilder: (context, index) {
                  return Container(
                    margin: const EdgeInsets.all(12.0),
                    color: randNum == index + 10
                        ? Colors.cyan
                        : Colors.yellowAccent,
                    child: GestureDetector(
                      child: Text(
                        "${index + 10}",
                        style: TextStyle(
                            fontSize:
                                MediaQuery.of(context).size.height * 0.09),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                },
                itemCount: 18,
              ),
            ),
          ),
        );
    }
  }

  check(String transcription) {
    if (transcription.split(' ').last.split('').reversed.skip(1).first +
            transcription.split(' ').last.split('').reversed.first ==
        randNum.toString()) {
      randNum = Random().nextInt(18) + 10;
      score += 1;
    } else if (transcription.toLowerCase().contains('turn on the lights')) {
      GetStorage().write('lampStatus', true);
    } else if (transcription.toLowerCase().contains('turn off the lights')) {
      GetStorage().write('lampStatus', false);
    }
  }
}
