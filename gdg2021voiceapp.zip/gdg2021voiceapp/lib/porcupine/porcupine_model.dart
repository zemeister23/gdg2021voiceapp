import 'package:flutter/material.dart';
import 'package:porcupine_flutter/porcupine.dart';
import 'package:porcupine_flutter/porcupine_error.dart';
import 'package:porcupine_flutter/porcupine_manager.dart';

class PorcupineProvider with ChangeNotifier {
  BuildContext? context;
  PorcupineProvider({this.context}) {
    try {
      createPorcupineManager().then((value) => listenForWake());
    } catch (e) {
      debugPrint(e.toString());
    }
  }
  PorcupineManager? porcupineManager;
  final accessKey =
      "xcVy8tsSrdwOXLt59AyXfxjwv2CEU3CF2sn2aHe+Huuc7h9Y9kRa3w=="; // AccessKey obtained from Picovoice Console (https://picovoice.ai/console/)

  Future<void> createPorcupineManager() async {
    try {
      porcupineManager = await PorcupineManager.fromBuiltInKeywords(accessKey,
          [BuiltInKeyword.PICOVOICE, BuiltInKeyword.JARVIS], _wakeWordCallback);
      debugPrint("MANAGER CREATED !");
    } on PorcupineException catch (err) {
      debugPrint("MANAGER ERROR !: ${err.message}");
    }
  }

  void _wakeWordCallback(int keywordIndex) {
    if (keywordIndex == 0) {
      debugPrint("PICOVOICE DETECTED !");
    } else if (keywordIndex == 1) {
      debugPrint("PORCUPINE DETECTED !");
      porcupineManager!.delete().then((value) => debugPrint("statement"));
    }
  }

  void listenForWake() async {
    await porcupineManager!.start();
    notifyListeners();
  }
}
