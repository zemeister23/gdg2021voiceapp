import 'package:flutter/material.dart';
import 'package:flutter_speech/flutter_speech.dart';
import 'package:texttospeecch/porcupine/porcupine_model.dart';

import 'language_model.dart';

class SpeechModelProvider with ChangeNotifier {
  SpeechModelProvider() {
    activateSpeechRecognizer();
  }
  late SpeechRecognition _speech;

  bool _speechRecognitionAvailable = false;
  bool _isListening = false;
  String transcription = 'Speak';

  //String _currentLocale = 'en_US';
  Language selectedLang = const Language('English', 'en_US');

  // Platform messages are asynchronous, so we initialize in an async method.
  void activateSpeechRecognizer() {
    _speech = SpeechRecognition();
    _speech.setAvailabilityHandler(onSpeechAvailability);
    _speech.setRecognitionStartedHandler(onRecognitionStarted);
    _speech.setRecognitionResultHandler(onRecognitionResult);
    _speech.setRecognitionCompleteHandler(onRecognitionComplete);
    _speech.setErrorHandler(errorHandler);
    _speech.activate('en_EN').then((res) {
      _speechRecognitionAvailable = res;
    });
  }

  void start() => _speech.activate(selectedLang.code).then((_) {
        return _speech.listen().then((result) {
          _isListening = result;
        });
      });

  void cancel() => _speech.cancel().then((_) {
        _isListening = false;
        PorcupineProvider();

      });

  void stop() => _speech.stop().then((_) {
        _isListening = false;
      });

  void onSpeechAvailability(bool result) {
    _speechRecognitionAvailable = result;
  }

  void onRecognitionResult(String text) {
    transcription = text;
    
    notifyListeners();
  }

  void onRecognitionStarted() {
    _isListening = true;
  }

  void onRecognitionComplete(String text) {
    _isListening = false;
    cancel();
    notifyListeners();
  }

  void errorHandler() => activateSpeechRecognizer();
}
