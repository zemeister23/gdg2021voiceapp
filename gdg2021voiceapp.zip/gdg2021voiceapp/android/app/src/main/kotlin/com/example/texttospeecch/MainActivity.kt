package com.example.texttospeecch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
